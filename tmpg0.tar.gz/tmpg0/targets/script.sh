#!/bin/bash
# comment line
echo "what a fine day: "
date
./c5.0 -f Trial -r -m1 -c100 -u100 > Trial.txt