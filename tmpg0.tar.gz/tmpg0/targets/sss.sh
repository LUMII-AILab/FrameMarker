#!/bin/bash
echo -n  $1
echo "fine"
date

