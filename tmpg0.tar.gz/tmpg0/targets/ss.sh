#!/bin/bash
cp Trial.costs `echo -n $1; echo ".costs"`
./c5.0 -f $1 -r -m1 -c100 > `echo -n $1; echo ".txt"`
more `echo -n $1; echo ".txt"`
