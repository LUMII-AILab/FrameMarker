#!/bin/bash
./ss.sh Being_born
./ss.sh Being_employed
./ss.sh Change_of_leadership
./ss.sh Death
./ss.sh Earnings_and_losses
./ss.sh Education_teaching
./ss.sh Employment_end
./ss.sh Hiring
./ss.sh Intentionally_create
./ss.sh Lending
./ss.sh Membership
./ss.sh Participation
./ss.sh People_by_age
./ss.sh People_by_vocation
./ss.sh Personal_relationship
./ss.sh Possession
./ss.sh Product_line
./ss.sh Residence
./ss.sh Statement
./ss.sh Trial
./ss.sh Win_prize



